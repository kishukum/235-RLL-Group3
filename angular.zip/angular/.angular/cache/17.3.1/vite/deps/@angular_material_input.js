import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-YKX25XPQ.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-I576CIP6.js";
import "./chunk-4RK6SPMU.js";
import "./chunk-FRVF6S6P.js";
import "./chunk-WJUDUU5Y.js";
import "./chunk-WDF32WIX.js";
import "./chunk-K733Z6CI.js";
import "./chunk-SXIXOCJ4.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
