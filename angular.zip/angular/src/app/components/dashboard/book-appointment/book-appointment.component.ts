import { NgClass, NgFor, NgIf } from '@angular/common';
import { Component, Renderer2 } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatDatepickerModule} from '@angular/material/datepicker';
import { MatSelectModule} from '@angular/material/select';
import { MatFormFieldModule} from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MedicalService } from '../../../services/medical.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';

@Component({
  selector: 'app-book-appointment',
  standalone: true,
  imports: [NgClass,NgIf,NgFor,FormsModule,ReactiveFormsModule,MatDatepickerModule,MatSelectModule,MatFormFieldModule,MatInputModule],
  templateUrl: './book-appointment.component.html',
  styleUrl: './book-appointment.component.css'
})
export class BookAppointmentComponent {
  public appointForm: FormGroup;
  public submitted: boolean = false;
  //public captcha: string = '';
  public timeSlots: string[] = [];
  public openTimeOverlay: boolean = false;
  public selectedTime: string | undefined;
  public doctorsList!: any[];
  public appointments!: any[];

  constructor(private formbuilder: FormBuilder,private medicalSrv: MedicalService ,private _snackBar: MatSnackBar,private router:Router){

    for (let i = 9; i < 22; i++) {
      const hours = i < 10 ? '0' + i : '' + i;
      this.timeSlots.push(hours + ':00');
      this.timeSlots.push(hours + ':30');
    }

    this.appointForm = this.formbuilder.group({
      doctor: this.formbuilder.group({
        id: ['', [Validators.required]],
      }),
      patient: this.formbuilder.group({
        id: this.medicalSrv.getId(),
      }),
      appointmentAt: ['']
    })
  }

  ngOnInit() {
    this.getAllDoctors();
    this.getAllAppointments();
  }

  public onSubmit(){
    if(!this.appointForm.invalid) {
      this.submitted = true;
      if (this.hasAppointmentsInSameWeek(this.appointments , this.appointForm.get('appointmentAt'))) {
        this._snackBar.open('Cannot book another appointment within the same week.', '', this.medicalSrv.matConfig());
      } 
      else{
      this.medicalSrv.bookAppointment(this.appointForm.getRawValue()).subscribe(res=>{
        this._snackBar.open('Appointment Booked','',this.medicalSrv.matConfig())
        this.router.navigateByUrl('dashboard/patient/history')
        this.appointForm.reset();
      },err=>{
        this._snackBar.open(err,'',this.medicalSrv.matConfig())
      })
    }
    }
  }

  selectTime(time: string) {
    this.selectedTime = time;
    const date = new Date(this.appointForm.get('appointmentAt')?.value);
    const formattedDate = date?.toISOString()?.slice(0, 10);
    const formattedDateTime = formattedDate + 'T' + time+ ':00'
    this.appointForm.get('appointmentAt')?.setValue(formattedDateTime)
    this.closeOverlay();
  }
  
  closeOverlay() {
    this.openTimeOverlay = false;
  }

  public get f() {
    return this.appointForm.controls;
  }
  
  public getAllDoctors(){
    this.medicalSrv.getAllDoctors().subscribe(res=>{
      this.doctorsList = res;
    },err=>{
      this.doctorsList = [];
    })
  }

  public getAllAppointments(){
    this.medicalSrv.getAppointmentById().subscribe(res => {
      this.appointments = res;
  })
}

  hasAppointmentsInSameWeek(userAppointments: any[], newAppointmentDate: any): boolean {
    const currentWeekStartDate = new Date();
    currentWeekStartDate.setDate(currentWeekStartDate.getDate() - currentWeekStartDate.getDay()); // Start of the current week

    const currentWeekEndDate = new Date(currentWeekStartDate);
    currentWeekEndDate.setDate(currentWeekStartDate.getDate() + 6); // End of the current week

    for (const appointment of userAppointments) {
      const appointmentDate = new Date(appointment.appointmentAt);
      if (appointmentDate >= currentWeekStartDate && appointmentDate <= currentWeekEndDate) {
        return true; 
      }
    }
    return false; 
  }
}
