import { Routes } from '@angular/router';
import { MedicineaddComponent } from './pharma/medicineadd/medicineadd.component';
import { PharmaComponent } from './pharma/pharma.component';
import { HistoryComponent } from './history/history.component';

export const PHARMA_ROUTES : Routes = [
  { path: 'pharma', component: PharmaComponent },
  { path: 'add-medicine', component: MedicineaddComponent}
]
