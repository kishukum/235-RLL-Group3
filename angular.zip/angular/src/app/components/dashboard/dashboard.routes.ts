import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { AuthunticationGuard } from '../../authuntication.guard';
import { NotFoundComponent } from '../not-found/not-found.component';

export const DASHBOARD_ROUTES : Routes = [
  { path: '', component: DashboardComponent },
  { path: 'patient', loadChildren: () => import('./patient.routes').then((r) => r.PATIENT_ROUTES), canActivate:[AuthunticationGuard]},
  { path: 'pharmacist', loadChildren: () => import('./pharma.routes').then((r) => r.PHARMA_ROUTES), canActivate:[AuthunticationGuard]},
  { path: 'executive', loadChildren: () => import('./executive.routes').then((r) => r.EXECUTIVE_ROUTES), canActivate:[AuthunticationGuard]},
  { path: 'doctor', loadChildren: () => import('./doctor.routes').then((r) => r.DOCTOR_ROUTES), canActivate:[AuthunticationGuard]},
]
