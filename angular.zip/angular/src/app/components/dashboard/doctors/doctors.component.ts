import { Component, ViewChild } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MedicalService } from '../../../services/medical.service';

@Component({
  selector: 'app-doctors',
  standalone: true,
  imports: [MatTableModule, MatFormFieldModule, MatInputModule, FormsModule],
  templateUrl: './doctors.component.html',
  styleUrl: './doctors.component.css'
})
export class DoctorsComponent {

  public displayedColumns: string[] = ['Id', 'Name', 'Visitations'];
  public dataSource!: MatTableDataSource<DoctorData>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  public searchTerm: any;
  public doctorsList!: DoctorData[];


  constructor(private medicalSrv: MedicalService) { }

  ngOnInit() {
    this.getAllDoctors();
  }
  
  // Apply filter based on the search term
  applyFilter(): void {
    this.dataSource.filter = this.searchTerm.trim().toLowerCase();
  }

  public getAllDoctors(){
    this.medicalSrv.getAllDoctors().subscribe(res=>{
      this.doctorsList = res;
      this.dataSource = new MatTableDataSource(this.doctorsList);
      this.dataSource.paginator = this.paginator;
    },err=>{
      this.doctorsList = [];
    })
  }


}
export interface DoctorData {
  id: number;
  name: string;
  visitations: string;
}

