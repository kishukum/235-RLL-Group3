import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatPaginator } from '@angular/material/paginator';
import { FormsModule } from '@angular/forms';
import { MedicalService } from '../../../services/medical.service';
import { DatePipe } from '@angular/common';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-history',
  standalone: true,
  imports: [MatTableModule, MatFormFieldModule, MatInputModule, FormsModule, DatePipe],
  templateUrl: './history.component.html',
  styleUrl: './history.component.css',
  host: { ngSkipHydration: 'true' },
})
export class HistoryComponent implements OnInit {

  public displayedColumns: string[] = ['Id', 'Name', 'Patient Name','Appointment', 'Status'];
  public dataSource!: MatTableDataSource<appointmntsHistory>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  public searchTerm: any
  public appointments!: appointmntsHistory[];


  constructor(public medicalSrv: MedicalService, private _snackBar: MatSnackBar) {
    const userRole = this.medicalSrv.getRole();
    if (userRole === 'executive') {
      this.displayedColumns.push('Action');
    }
  }

  ngOnInit() {
    this.getAppointmentsById();
  }

  // Apply filter based on the search term
  applyFilter(): void {
    this.dataSource.filter = this.searchTerm.trim()?.toLowerCase();
    this.dataSource.filterPredicate = (data: appointmntsHistory, filter: string) => {
      return data.status?.toLowerCase().includes(filter) || 
             data.appointment?.toLowerCase().includes(filter) || 
             data.patient?.name.toLowerCase().includes(filter) ||
             data.doctor?.name.toLowerCase().includes(filter); 
    };
    this.dataSource.filter = this.searchTerm;  
  }

  getAppointmentsById() {
    if( this.medicalSrv.getRole() == 'executive'){
    this.medicalSrv.getAllAppointment().subscribe(res => {
      this.appointments = res;
      this.dataSource = new MatTableDataSource(this.appointments);
      this.dataSource.paginator = this.paginator;
    })
  }
  else{
    this.medicalSrv.getAppointmentById().subscribe(res => {
      this.appointments = res;
      this.dataSource = new MatTableDataSource(this.appointments);
      this.dataSource.paginator = this.paginator;
    })
  }
  }

  public updateAppointment(id: any, status: any){
  this.medicalSrv.updateAppointment(id, status).subscribe(res=>{
    this._snackBar.open('Appointment Updated','',this.medicalSrv.matConfig());
    this.getAppointmentsById();
  })
  }
}

export interface appointmntsHistory {
  id: number;
  patient: {
    id: number;
    name: string;
  }
  doctor: {
    id: number;
    name: string;
  }
  appointment: string;
  status: string;
}
