import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatFormFieldModule} from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import { MedicalService } from '../../../services/medical.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-pharma',
  standalone: true,
  imports: [MatTableModule, MatFormFieldModule, MatInputModule,FormsModule],
  templateUrl: './pharma.component.html',
  styleUrl: './pharma.component.css',
  host: { ngSkipHydration: 'true' }
})

export class PharmaComponent implements OnInit{

  public displayedColumns: string[] = ['Id', 'Name', 'Quantity', 'Price', 'Discounted Price'];
  public dataSource!: MatTableDataSource<PharmaData>;
  @ViewChild(MatPaginator, { static: true }) paginator!: MatPaginator;
  public searchTerm:any;
  public medicinesList!: PharmaData[];


 
  constructor(public medicalSrv: MedicalService, private router: Router,private cdr: ChangeDetectorRef) {

    const userRole = this.medicalSrv.getRole();
    if (userRole === 'pharmacist') {
      this.displayedColumns.push('Action');
    }

   }

  ngOnInit() {
    this.getAllMedicines();
  }
    // Apply filter based on the search term
    applyFilter(): void {
      this.dataSource.filter = this.searchTerm.trim().toLowerCase();
    }
    
  public onCreate() {
    this.router.navigateByUrl('dashboard/pharmacist/add-medicine', {
      state: { onCreate: true }
    });
  }

  public onEdit(mData: any): void {
    this.router.navigateByUrl('dashboard/pharmacist/add-medicine', { state: { medicineInfo: mData, onEdit: true } });
  }

  public onDelete(data: any) {
    this.medicalSrv.deleteMedicine(data.id).subscribe((data) => {
      this.medicinesList.splice(data.id, 1);
      this.getAllMedicines();
    },err=>{
      this.getAllMedicines();
    });
  }

  public getAllMedicines() {
    this.medicalSrv.getAllMedicines().subscribe(data=>{
      this.medicinesList = data;
      this.dataSource = new MatTableDataSource(this.medicinesList);
      this.dataSource.paginator = this.paginator;  
    })
  }

}
export interface PharmaData {
  id: number;
  name: string;
  quantityAvailable: string;
  price: string;
}
