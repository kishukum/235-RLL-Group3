import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MedicalService } from '../../../../services/medical.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-medicineadd',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule],
  templateUrl: './medicineadd.component.html',
  styleUrl: './medicineadd.component.css'
})
export class MedicineaddComponent implements OnInit {

  public medicineForm: FormGroup;
  public submitted: boolean = false;
  public onEdit: boolean = false;

  constructor(private formbuilder: FormBuilder, private medicalSrv: MedicalService,private router:Router,private _snackBar: MatSnackBar ) {

    this.medicineForm = this.formbuilder.group({
      id: [''],
      name: [''],
      quantityAvailable: [''],
      price: ['']
    })
  }

  ngOnInit() {
    if (history.state.medicineInfo != null) {
      this.onEdit = history.state.onEdit;
      this.medicineForm.patchValue(history.state.medicineInfo);
    }
  }

  public onSubmit() {
    this.submitted = true;
    if (!this.onEdit) {
      this.medicalSrv.addMedicine(this.medicineForm.getRawValue()).subscribe(res => {
        this._snackBar.open('Medicine Added','',this.medicalSrv.matConfig())
        this.router.navigateByUrl('dashboard/pharmacist/pharma');
      }, err => {
        this._snackBar.open(err,'',this.medicalSrv.matConfig())
      })
    }
    else {
      this.medicalSrv.updateMedicine(this.medicineForm.getRawValue()).subscribe(res => {
        this._snackBar.open('Medicine Updated','',this.medicalSrv.matConfig())
        this.router.navigateByUrl('dashboard/pharmacist/pharma')
      }, err => {
        this._snackBar.open(err,'',this.medicalSrv.matConfig())
      })
    }
  }
}
