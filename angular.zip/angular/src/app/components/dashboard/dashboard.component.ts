import { Component, OnInit } from '@angular/core';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MedicalService } from '../../services/medical.service';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [SidebarComponent, FormsModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit{
  public UserData!: any;

  constructor(private medicalSrv:MedicalService) {}

  ngOnInit() {
   this.UserData = this.medicalSrv.getUser();
   this.UserData = JSON.parse(this.UserData)
  }

}
