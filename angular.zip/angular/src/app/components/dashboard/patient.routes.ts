import { Routes } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { BookAppointmentComponent } from './book-appointment/book-appointment.component';
import { HistoryComponent } from './history/history.component';
import { PharmaComponent } from './pharma/pharma.component';
import { DoctorsComponent } from './doctors/doctors.component';
import { AuthunticationGuard } from '../../authuntication.guard';

export const PATIENT_ROUTES : Routes = [
  { path: '', component: DashboardComponent },
  { path: 'book-appointment', component: BookAppointmentComponent , canActivate:[AuthunticationGuard]},
  { path: 'history', component: HistoryComponent },
  { path: 'pharma', component:  PharmaComponent},
  { path: 'doctors', component:  DoctorsComponent}
]
