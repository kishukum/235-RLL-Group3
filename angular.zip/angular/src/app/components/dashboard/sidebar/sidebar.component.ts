import { Component, OnInit ,Inject} from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { MedicalService } from '../../../services/medical.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterLink,RouterLinkActive],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent implements OnInit{

  public currentRoute: any;

  constructor(public medicalSrv: MedicalService, @Inject(DOCUMENT) private document: Document){}

  ngOnInit() {
    this.currentRoute = this.medicalSrv.getRole();
  }
  
  public sidebarToggle() {
    if(window.innerWidth<=726){
      this.document.body.classList.toggle('toggle-sidebar');
    }
}

}
