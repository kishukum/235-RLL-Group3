import { Component, OnInit } from '@angular/core';
import { MedicalService } from '../../services/medical.service';

@Component({
  selector: 'app-logout',
  standalone: true,
  imports: [],
  templateUrl: './logout.component.html',
  styleUrl: './logout.component.css'
})
export class LogoutComponent implements OnInit{
 
  constructor(private medicalSrv: MedicalService){}

  ngOnInit() {
    this.medicalSrv.logout();
  }

}
