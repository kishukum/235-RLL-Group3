import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { MedicalService } from '../../services/medical.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-home',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './home.component.html',
  styleUrl: './home.component.css'
})
export class HomeComponent {

  constructor(public medicalSrv: MedicalService, private _snakbar: MatSnackBar) {}

  public isBookAppTrue() :any{
   if(this.medicalSrv.getRole() == 'patient'){
      return 'dashboard/patient/book-appointment';
   }
   else{
     return 'login'
   }
  }
}
