import { NgClass, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MedicalService } from '../../../services/medical.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule,NgClass,NgIf],
  templateUrl: './reset-password.component.html',
  styleUrl: './reset-password.component.css'
})
export class ResetPasswordComponent {

  public resetPasswordForm: FormGroup;
  public submitted:boolean = false;

  constructor(private formBuilder: FormBuilder, private router:Router,private medicalSrv: MedicalService,private _snackBar:MatSnackBar) {
    this.resetPasswordForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      oldPassword: ['', [Validators.required]],
    })
  }

  onSubmit() {
    this.submitted = true;
    if (this.resetPasswordForm.valid) {
     this.medicalSrv.resetPassword(this.resetPasswordForm.getRawValue()).subscribe((res: any) =>{
      this._snackBar.open('Reset Password success','',this.medicalSrv.matConfig())
      this.router.navigateByUrl('login')
     },(err :any)=>{
      this._snackBar.open('Reset Password success','',this.medicalSrv.matConfig());
      this.router.navigateByUrl('login')
     })
    }
  }
  public get f() {
    return this.resetPasswordForm.controls;
  }

}
