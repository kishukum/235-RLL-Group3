import { NgClass, NgFor, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MedicalService } from '../../../services/medical.service';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, NgClass, NgIf, NgFor, ReactiveFormsModule, RouterLink,MatSnackBarModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent implements OnInit {
  public loginForm: FormGroup;
  public submitted: boolean = false;
  public captcha: string = '';
  public isDoctor: boolean = false;


  constructor(private formbuilder: FormBuilder, public medicalSrv: MedicalService, private router: Router,private _snackBar: MatSnackBar) {
    this.loginForm = this.formbuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(20)]],
      captcha: ['', [Validators.required, this.validateCaptcha.bind(this)]]
    })
  }

  ngOnInit() {
    this.generateCaptcha(6);
  }

  public onSubmit() {
    this.submitted = true;
    if (!this.loginForm.invalid) {
      this.medicalSrv.signIn(this.loginForm.getRawValue()).subscribe(res => {
        this.medicalSrv.setUser(res);
        const role = this.medicalSrv.getRole();
        switch (role) {
          case 'patient':
            this.router.navigate(['/dashboard/patient/book-appointment']);
            break;
          case 'doctor':
            this.router.navigate(['/dashboard/doctor/history']);
            break;
          case 'pharmacist':
            this.router.navigate(['/dashboard/pharmacist/pharma']);
            break;
          case 'executive':
            this.router.navigate(['/dashboard/executive/history']);
            break;
          default:
            // Handle invalid or unrecognized role
            break;
        }
      }, err => {      
        this._snackBar.open(err,'',this.medicalSrv.matConfig())
      })
    }
  }

  public generateCaptcha(length: number): string {
    this.captcha = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
      this.captcha += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return this.captcha;
  }

  public validateCaptcha(control: AbstractControl): { [key: string]: any } | null {
    if (control.value !== this.captcha) {
      return { invalidCaptcha: true };
    }
    return null;
  }

  public get f() {
    return this.loginForm.controls;
  }

  public toggleLink() {
    this.isDoctor = !this.isDoctor;
  }
  public setRole(role: string) {
    this.medicalSrv.setRole(role);
  }

}
