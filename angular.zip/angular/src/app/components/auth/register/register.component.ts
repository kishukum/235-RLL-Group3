import { NgClass, NgFor, NgIf } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { MedicalService } from '../../../services/medical.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [NgIf, NgFor, FormsModule, ReactiveFormsModule, NgClass, RouterLink],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {

  public registerForm: FormGroup;
  public submitted: boolean = false;
  public captcha: string = '';
  public isDoctor:boolean = false;


  constructor(private formbuilder: FormBuilder, private router: Router, private medicalSrv: MedicalService,private _snackBar: MatSnackBar) {
    this.registerForm = this.formbuilder.group({
      email: ['', [Validators.required, Validators.email]],
      name: ['', [Validators.required, Validators.pattern("^[A-Za-z]+[A-Za-z ]*$"), Validators.minLength(3)]],
      contactNumber: ['', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]],
      password: ['', [Validators.required, Validators.minLength(6), Validators.maxLength(20)]],
      gender: ['', Validators.required],
      specialization: [''],
      visitations: [''],
      age: ['', Validators.required],
      captcha: ['', [Validators.required, this.validateCaptcha.bind(this)]]
    })

  }

  ngOnInit() {
    this.generateCaptcha(6);
  }

  public onSubmit() {
    this.submitted = true;
    if (!this.registerForm.invalid) {
      if (this.isDoctor) {
        this.medicalSrv.signDoc(this.registerForm.getRawValue()).subscribe(res => {
          this.router.navigateByUrl('login')
        }, err => {
          this._snackBar.open(err, '', this.medicalSrv.matConfig())
        })
      }
      else {
        this.medicalSrv.signUp(this.registerForm.getRawValue()).subscribe(res => {
          this.router.navigateByUrl('login')
        }, err => {
          this._snackBar.open(err, '', this.medicalSrv.matConfig())
        })
      }
    }
  }

  public get f() {
    return this.registerForm.controls;
  }

  public generateCaptcha(length: number): string {
    this.captcha = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    for (let i = 0; i < length; i++) {
      this.captcha += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return this.captcha;
  }

  public validateCaptcha(control: AbstractControl): { [key: string]: any } | null {
    if (control.value !== this.captcha) {
      return { invalidCaptcha: true };
    }
    return null;
  }

  public toggleLink() {
    this.isDoctor = !this.isDoctor;
  }
}
