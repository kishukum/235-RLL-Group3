import { Component, Inject, OnInit, HostListener } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MedicalService } from '../../services/medical.service';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent implements OnInit {

  public isMobileView!: boolean;

  constructor(public medicalSrv: MedicalService, @Inject(DOCUMENT) private document: Document) { }

  ngOnInit() {
    this.onResize(null);
  }

  public sidebarToggle() {
    if (window.innerWidth <= 726) {
      this.document.body.classList.toggle('toggle-sidebar');
    }
  }
  @HostListener('window:resize', ['$event'])
  onResize(event: any) {
    if (typeof window !== 'undefined') {
    this.isMobileView = window.innerWidth <= 726;
    }
  }

}
