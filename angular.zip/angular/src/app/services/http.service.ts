import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs";
import { Router } from "@angular/router";

const baseUrl = 'http://localhost:8080/api';


@Injectable({
  providedIn: 'root'
})

export class HttpService {

  public sessionExpire:boolean = false;

  constructor(private http: HttpClient, private router:Router) { }

  getRequest(url: string, body?: any, header?: any): Observable<any> {
    return this.http.get(`${baseUrl}/${url}`, header).pipe(
      catchError(err => this.catchAuthError(err)),
    );
  }

  postRequest(url: string, body?: any, header?: any): Observable<any> {
    return this.http.post(`${baseUrl}/${url}`, body, header).pipe(
      catchError(err => this.catchAuthError(err)),
    );
  }

  putRequest(url: string, body?: any, header?: any): Observable<any> {
    return this.http.put(`${baseUrl}/${url}`, body, header).pipe(
      catchError(err => this.catchAuthError(err)),
    );
  }

  deleteRequest(url: string, body?: any, header?: any): Observable<any> {
    return this.http.delete(`${baseUrl}/${url}`).pipe(
      catchError(err => this.catchAuthError(err)),
    );
  }

 /**
   * Catch Server Error & Redirect to error page.
   * @param error .
   * @returns
   */
 catchAuthError(error: any) {
  switch (error.status) {
  
    case 401: {
      this.router.navigate(['/login']);
      break;
    }
    case 403: {
      this.router.navigate(['/error/403']);
      break;
    }
    default: {
      break;
    }
  }
return throwError(() => error.error)
}
}
