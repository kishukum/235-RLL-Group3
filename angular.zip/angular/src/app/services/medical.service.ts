import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { Router } from '@angular/router';
import { MatSnackBarConfig } from '@angular/material/snack-bar';

@Injectable({
  providedIn: 'root'
})

export class MedicalService {

  constructor(private httpSrv: HttpService, private router: Router) { }

  private readonly ROLE_KEY = 'user_role';

  public signIn(user: any) {
    return this.httpSrv.postRequest(`login`, user);
  }

  public signUp(user: any) {
    return this.httpSrv.postRequest(`patient/register`, user);
  }

  public signDoc(user: any) {
    return this.httpSrv.postRequest(`doctor/register`, user);
  }

  public setUser(data: any) {
    if (typeof localStorage !== 'undefined') {
    localStorage?.setItem("ID", data.id);
    localStorage?.setItem("USER_RES", JSON.stringify(data));
    }
  }
  public getUser(): any {
    if (typeof localStorage !== 'undefined') {
      return localStorage?.getItem("USER_RES");
      }
  }

  public getId(): any {
    if (typeof localStorage !== 'undefined') {
    return localStorage?.getItem('ID');
    }
  }
  
  public setRole(role: string) {
    if (typeof localStorage !== 'undefined') {
    localStorage?.setItem(this.ROLE_KEY, role);
    }
  }

  public getRole(): string {
    if (typeof localStorage !== 'undefined') {
    return localStorage?.getItem(this.ROLE_KEY) || 'patient';
    }
    else{
      return '';
    }
  }

  public isLogin(): boolean {
    if (typeof localStorage !== 'undefined') {
    return localStorage?.getItem('ID') ? true : false;
    }
    else{
      return false;
    }
  }

  public bookAppointment(data: any){
    return this.httpSrv.postRequest(`book/appointment`, data);
  }

  public getAllAppointment(){
    return this.httpSrv.getRequest(`all/appointments`);
  }

  public getAppointmentById(){
    return this.httpSrv.getRequest( this.getRole() == 'patient' ? `appointments/patient/${this.getId()}` : `appointments/patient/${this.getId()}`);
  }
  
  public updateAppointment(id:any, status:any){
    return this.httpSrv.putRequest(`appointment/${id}/${status}`);
  }
  public getAllDoctors(){
    return this.httpSrv.getRequest(`doctors`);
  }

  public getAllMedicines(){
    return this.httpSrv.getRequest(`tablets`);
  }

  public addMedicine(data: any){
    return this.httpSrv.postRequest(`tablet`, data);
  }

  public updateMedicine(data: any){
    return this.httpSrv.putRequest(`tablet`, data);
  }

  public deleteMedicine(id: any){
    return this.httpSrv.deleteRequest(`tablet/${id}`);
  }

  public resetPassword(resetData: any){
    return this.httpSrv.putRequest(`reset/password`, resetData)
  }

  public logout() {
    localStorage?.clear();
    this.router.navigateByUrl('/login')
  }

  public matConfig(){
   const defaultConfig: MatSnackBarConfig = {
      horizontalPosition: 'center',
      verticalPosition: 'top',
      duration: 2000 // 5 seconds
    };

    return defaultConfig;
  }

}
