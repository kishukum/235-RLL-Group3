import { Routes } from '@angular/router';
import { LoginComponent } from './components/auth/login/login.component';
import { RegisterComponent } from './components/auth/register/register.component';
import { HomeComponent } from './components/home/home.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { LogoutComponent } from './components/logout/logout.component';
import { AuthunticationGuard } from './authuntication.guard';
import { ResetPasswordComponent } from './components/auth/reset-password/reset-password.component';

export const routes: Routes = [
    { path: '', component: HomeComponent},
    { path: 'login', component: LoginComponent},
    { path: 'register', component: RegisterComponent},
    { path: 'reset-password', component: ResetPasswordComponent},
    { path: 'dashboard', loadChildren: () => import('././components/dashboard/dashboard.routes').then((r) => r.DASHBOARD_ROUTES), canActivate:[AuthunticationGuard]},
    { path: 'logout', component: LogoutComponent},
    { path: '**', component: NotFoundComponent, data: { message: 'not found' },}
];
