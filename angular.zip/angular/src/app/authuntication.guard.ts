import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { MedicalService } from './services/medical.service';

@Injectable({
  providedIn: 'root'
})
export class AuthunticationGuard implements CanActivate {

  constructor(private medicalSrv: MedicalService, private router: Router) {}

  canActivate() :boolean  {
    if (!this.medicalSrv.isLogin()) {  
        this.router.navigateByUrl("/login");  
    }  
    return this.medicalSrv.isLogin();  
   }
  
}
