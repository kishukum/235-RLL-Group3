package com.appointment.doctor.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.appointment.doctor.entity.Appointment;

public interface AppointmentService {

	ResponseEntity<Appointment> bookAppointment(Appointment appointment);

	ResponseEntity<List<Appointment>> getDoctorsAppointment(int id, String status);

	ResponseEntity<?> updateStatus(int id, String status);

	ResponseEntity<?> get(int id);

	ResponseEntity<List<Appointment>> getPatientAppointments(int id, String status);

	ResponseEntity<List<Appointment>> getPatientAppointmentsByName(String name);

	ResponseEntity<List<Appointment>> getAllAppointment();

}
