package com.appointment.doctor.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.appointment.doctor.entity.Patient;
import com.appointment.doctor.repository.PatientRepository;
import com.appointment.doctor.service.PatientService;
@Service
public class PatientServiceImpl implements PatientService{
	
	@Autowired
	private PatientRepository patientRepository;

	@Override
	public ResponseEntity<?> savePatient(Patient patient) {
		if(patientRepository.existsByEmail( patient.getEmail())) {
			return new ResponseEntity<String>("Patient already exist",HttpStatus.BAD_REQUEST);

		}
		return new ResponseEntity<Patient>(patientRepository.save(patient),HttpStatus.OK);
	}

}
