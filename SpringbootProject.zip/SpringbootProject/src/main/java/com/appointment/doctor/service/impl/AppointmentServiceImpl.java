package com.appointment.doctor.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.entity.Patient;
import com.appointment.doctor.repository.AppointmentsRepository;
import com.appointment.doctor.repository.DoctorsRepository;
import com.appointment.doctor.repository.PatientRepository;
import com.appointment.doctor.service.AppointmentService;
@Service
public class AppointmentServiceImpl implements AppointmentService{

	@Autowired
	private AppointmentsRepository appointmentRepository;
	
	@Autowired
	private DoctorsRepository doctorRepository;
	
	@Autowired
	private PatientRepository patientRepository;

	@Override
	public ResponseEntity<Appointment> bookAppointment(Appointment appointment) {
		Optional<Patient> p=patientRepository.findById(appointment.getPatient().getId());
		Optional<Doctor> d=  doctorRepository.findById(appointment.getDoctor().getId());
		appointment.setDoctor(d.get());
		appointment.setPatient(p.get());
		appointment.setStatus("PENDING");
		return new ResponseEntity<Appointment>(appointmentRepository.save(appointment),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Appointment>> getDoctorsAppointment(int id,String status) {
		if(status.equals("ALL")) {
			return new ResponseEntity<List<Appointment>>(appointmentRepository.findByDoctorId(id),HttpStatus.OK);
		}
		return new ResponseEntity<List<Appointment>>(appointmentRepository.findByDoctorIdAndStatus(id,status),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> updateStatus(int id, String status) {
		Optional<Appointment> app=appointmentRepository.findById(id);
		if(app.isEmpty()) {
			return new ResponseEntity<String>("not Found",HttpStatus.BAD_REQUEST);
		}
		Appointment appointment=app.get();
		appointment.setStatus(status);
		return new ResponseEntity<Appointment>(appointmentRepository.save(appointment),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> get(int id) {
		Optional<Appointment> app=appointmentRepository.findById(id);
		if(app.isEmpty()) {
			return new ResponseEntity<String>("not Found",HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Appointment>(app.get(),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Appointment>> getPatientAppointments(int id, String status) {
		if(status.equals("ALL")) {
			return new ResponseEntity<List<Appointment>>(appointmentRepository.findByPatientId(id),HttpStatus.OK);
		}
		return new ResponseEntity<List<Appointment>>(appointmentRepository.findByPatientAndStatus(id,status),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<Appointment>> getPatientAppointmentsByName(String name) {
		
		return new ResponseEntity<List<Appointment>>(appointmentRepository.findByPatientName(name),HttpStatus.OK);
	}
	@Override
	public ResponseEntity<List<Appointment>> getAllAppointment() {
		// TODO Auto-generated method stub
		return new ResponseEntity<List<Appointment>>(appointmentRepository.findAll(),HttpStatus.OK);
		
	}
}
