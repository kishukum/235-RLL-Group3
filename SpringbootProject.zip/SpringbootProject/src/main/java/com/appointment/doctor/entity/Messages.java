package com.appointment.doctor.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "messages")
public class Messages {
	
	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="sender_id")
	private int senderId;
	
	@Column(name="receiver_id")
	private int receiverId;
	
	@Column(name="message_at")
	private Date messageAt;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSenderId() {
		return senderId;
	}

	public void setSenderId(int senderId) {
		this.senderId = senderId;
	}

	public int getReceiverId() {
		return receiverId;
	}

	public void setReceiverId(int receiverId) {
		this.receiverId = receiverId;
	}

	public Date getMessageAt() {
		return messageAt;
	}

	public void setMessageAt(Date messageAt) {
		this.messageAt = messageAt;
	}

	@Override
	public String toString() {
		return "Messages [id=" + id + ", senderId=" + senderId + ", receiverId=" + receiverId + ", messageAt="
				+ messageAt + "]";
	}

	public Messages(int id, int senderId, int receiverId, Date messageAt) {
		super();
		this.id = id;
		this.senderId = senderId;
		this.receiverId = receiverId;
		this.messageAt = messageAt;
	}

	public Messages() {
		super();
	}
	
	

}
