package com.appointment.doctor.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "doctor")
public class Doctor {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="name")
	private String name;
	
	@Column(name="specialization")
	private String specialization;
	
	@Column(name="email")
	private String email;
	
	@Column(name="visitations")
	private String visitations;
	
	@Column(name="password")
	private String password;
	
	@Column(name = "contact_number")
    private String contactNumber;
	@Column(name = "age")
	private int age;
	@Column(name = "gender")
	private String gender;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSpecialization() {
		return specialization;
	}
	public void setSpecialization(String specialization) {
		this.specialization = specialization;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getVisitations() {
		return visitations;
	}
	public void setVisitations(String visitations) {
		this.visitations = visitations;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", specialization=" + specialization + ", email=" + email
				+ ", visitations=" + visitations + ", password=" + password + ", contactNumber=" + contactNumber
				+ ", age=" + age + ", gender=" + gender + "]";
	}
	public Doctor(int id, String name, String specialization, String email, String visitations, String password,
			String contactNumber, int age, String gender) {
		super();
		this.id = id;
		this.name = name;
		this.specialization = specialization;
		this.email = email;
		this.visitations = visitations;
		this.password = password;
		this.contactNumber = contactNumber;
		this.age = age;
		this.gender = gender;
	}
	public Doctor() {
		super();
	}

	
}
