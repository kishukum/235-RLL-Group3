package com.appointment.doctor.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.appointment.doctor.entity.Tablet;
@Repository
public interface TabletRepository extends JpaRepository<Tablet, Integer>{

	boolean existsByName(String name);
	Tablet  findByName(String name);

}
