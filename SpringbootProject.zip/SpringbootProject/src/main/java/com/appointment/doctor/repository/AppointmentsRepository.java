package com.appointment.doctor.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.appointment.doctor.entity.Appointment;
@Repository
public interface AppointmentsRepository extends JpaRepository<Appointment, Integer> {

	List<Appointment> findByDoctorId(int id);

	List<Appointment> findByDoctorIdAndStatus(int id, String status);

	List<Appointment> findByPatientId(int id);

	List<Appointment> findByPatientAndStatus(int id, String status);

	List<Appointment> findByPatientName(String name);

}
