package com.appointment.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.appointment.doctor.entity.Tablet;
import com.appointment.doctor.service.TabletsService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class TabletsController {
	
	@Autowired
	private TabletsService tabletsService;
	
	@PostMapping("/tablet")
	public ResponseEntity<?> save(@RequestBody Tablet tablet){
		return tabletsService.save(tablet);
	}
	
	@PutMapping("/tablet")
	public ResponseEntity<?> update(@RequestBody Tablet tablet){
		return tabletsService.update(tablet);

	}
	
	@GetMapping("/tablets")
	public ResponseEntity<List<Tablet>> getAll(){
		return tabletsService.getAll();
	}
	
	@GetMapping("/tablet/{id}")
	public ResponseEntity<?> getById(@PathVariable int id){
		return tabletsService.getById(id);
	}
	
	@DeleteMapping("/tablet/{id}")
	public ResponseEntity<String> delete(@PathVariable int id){
		return tabletsService.deleteById(id);

	}
	
	@GetMapping("/tablet/name/{name}")
	public ResponseEntity<?> getByName(@PathVariable String name){
		return tabletsService.getByName(name);
	}

}
