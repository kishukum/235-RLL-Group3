package com.appointment.doctor.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.service.DoctorsService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class DoctorsController {
	
	@Autowired
	private DoctorsService doctorsService;
	
	@PostMapping("/doctor/register")
	public ResponseEntity<?> save(@RequestBody Doctor doctor){
		return doctorsService.saveDoctor(doctor);
	}
	
	@GetMapping("/doctors")
	public ResponseEntity<List<Doctor>> getAll(@RequestParam(required = false) String specialization){
		return doctorsService.getAllDoctors(specialization);
	}
	

}
