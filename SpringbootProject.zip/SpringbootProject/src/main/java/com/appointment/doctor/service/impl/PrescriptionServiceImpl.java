package com.appointment.doctor.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Prescription;
import com.appointment.doctor.entity.Tablet;
import com.appointment.doctor.repository.AppointmentsRepository;
import com.appointment.doctor.repository.PrescriptionRepository;
import com.appointment.doctor.repository.TabletRepository;
import com.appointment.doctor.service.PrescriptionService;
@Service
public class PrescriptionServiceImpl implements PrescriptionService{

	@Autowired
	private PrescriptionRepository prescriptionRepository;
	
	@Autowired
	private AppointmentsRepository appointmentRepository;
	
	@Autowired
	private TabletRepository tabletrepository;

	@Override
	public ResponseEntity<?> save(Prescription prescription) {
		Optional<Appointment> app=appointmentRepository.findById(prescription.getAppointment().getId());
		if(app.isEmpty()) {
			return new ResponseEntity<String>("Not Found",HttpStatus.BAD_REQUEST);
		}
		prescription.setAppointment(app.get());
		List<Tablet> tablets= new ArrayList<>();
		List<Tablet> ts=prescription.getTablets();
		for(Tablet t: ts) {
			Optional<Tablet> opt=tabletrepository.findById(t.getId());
			if(opt.isPresent()) {
				tablets.add(opt.get());
			}
		}
		
		prescription.setTablets(tablets);
		return new ResponseEntity<Prescription>(prescriptionRepository.save(prescription),HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getPatientPrescription(int id) {
		List<Prescription> prescriptions=prescriptionRepository.findByAppointmentPatientId(id);
		return new ResponseEntity<List<Prescription>>(prescriptions,HttpStatus.OK);
	}

	@Override
	public ResponseEntity<?> getPrescription(int id) {
		Optional<Prescription> pres=prescriptionRepository.findById(id);
		if(pres.isEmpty()) {
			return new ResponseEntity<String>("Not Found",HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Prescription>(pres.get(),HttpStatus.OK);
	}
	
}
