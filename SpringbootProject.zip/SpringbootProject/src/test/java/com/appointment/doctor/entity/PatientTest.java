package com.appointment.doctor.entity;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {Patient.class })
@ExtendWith(SpringExtension.class)

public class PatientTest {
	@Autowired
    private Patient patient;

	@MockBean
	private AppointmentService appointmentService;
	@Test
	public void  testgetId()  throws Exception  {
		patient.getId();
			 }
	@Test
	public void  testsetId()  throws Exception  {
		patient.setId(0);
			 }

	@Test
	public void  testgetName()  throws Exception  {
		patient.getName();
			 }

	@Test
	public void  testsetName()  throws Exception  {
String name="rajj";		patient.setName(name);
			 }

	@Test
	public void  testgetEmail()  throws Exception  {
		patient.getEmail();
			 }

	@Test
	public void  testsetEmail()  throws Exception  {
String str="asf";	
patient.setEmail(str);
			 }

	@Test
	public void  testgetPassword()  throws Exception  {
		String email="tewe";	
		patient.getPassword();
			 }
	@Test
	public void  testsetPassword()  throws Exception  {
		String email="tewe";
		patient.setPassword(email);
			 }
	@Test
	public void  testgetContactNumber()  throws Exception  {
		String email="tewe";
		patient.getContactNumber();
			 }
	@Test
	public void  testsetContactNumber()  throws Exception  {
		String email="tewe";
		patient.setContactNumber(email);
			 }
	@Test
	public void  testgetAge()  throws Exception  {
		patient.getAge();
									 }

	@Test
	public void  testsetAge()  throws Exception  {
		int age=3;
		patient.setAge(age);
									 }

	@Test
	public void  testgetGender()  throws Exception  {
								String visitations="";	
								patient.getGender();
									 }

	@Test
	public void  testsetGender()  throws Exception  {
								String Gender="";	
								patient.setGender(Gender);
									 }

	@Test
    public void testToString() {
        Doctor doctor = new Doctor();
        Patient patient = new Patient();
        String status = "PENDING";
        LocalDateTime appointmentAt = LocalDateTime.now();

        Appointment appointment = new Appointment(1, doctor, patient, status, appointmentAt);
        String expectedToString = "Appointment [id=1, doctor=" + doctor + ", patient=" + patient + ", status=" + status
            + ", appointmentAt=" + appointmentAt + "]";

        assertEquals(expectedToString, appointment.toString());
    }
	@Test
    public void testPatientConstructor() {
        int id = 1;
        String name = "Alice Smith";
        String email = "alice@example.com";
        String password = "password123";
        String contactNumber = "+1234567890";
        int age = 30;
        String gender = "Female";

        Patient patient = new Patient(id, name, email, password, contactNumber, age, gender);

        assertEquals(id, patient.getId());
        assertEquals(name, patient.getName());
        assertEquals(email, patient.getEmail());
        assertEquals(password, patient.getPassword());
        assertEquals(contactNumber, patient.getContactNumber());
        assertEquals(age, patient.getAge());
        assertEquals(gender, patient.getGender());
    }
			 }
