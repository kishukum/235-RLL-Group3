package com.appointment.doctor.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.StringUtils;

import com.appointment.doctor.dto.LogIn;
import com.appointment.doctor.dto.ResetPassword;
import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.entity.Patient;
import com.appointment.doctor.repository.AppointmentsRepository;
import com.appointment.doctor.repository.DoctorsRepository;
import com.appointment.doctor.repository.PatientRepository;
import com.appointment.doctor.service.AppointmentService;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {LogInServiceImpl.class })
@ExtendWith(SpringExtension.class)
public class LogInServiceImplTest {

    @Autowired
	private LogInServiceImpl logInServiceImpl;

	@MockBean
	private DoctorsRepository doctorRepository;

	@MockBean
	private PatientRepository patientRepository;
	@MockBean
	private AppointmentsRepository appointmentRepository;
	 
	@Test
	public void contextLoads() {
	}
	@Test
    public void testLoginPatient() {
        String email = "patient@example.com";
        String password = "password";

        LogIn login = new LogIn(email, password);

        Patient patient = new Patient(1, "Patient Name", email, password, "+123456789", 30, "Male");
        when(patientRepository.existsByEmailAndPassword(email, password)).thenReturn(true);
        when(patientRepository.findByEmailAndPassword(email, password)).thenReturn(patient);
        ResponseEntity<?> response = logInServiceImpl.logIn(login);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody() instanceof Patient);
        assertEquals(patient, response.getBody());
    }

	 @Test
	    public void testResetPatientPassword() {
	        String email = "patient@example.com";
	        String oldPassword = "oldPassword";
	        String newPassword = "newPassword";

	        ResetPassword reset = new ResetPassword(email, oldPassword, newPassword);

	        Patient patient = new Patient(1, "Patient Name", email, oldPassword, "+123456789", 30, "Male");

	        when(patientRepository.existsByEmailAndPassword(email, oldPassword)).thenReturn(true);
	        when(patientRepository.findByEmail(email)).thenReturn(patient);
	        when(patientRepository.save(patient)).thenReturn(patient);

	        ResponseEntity<String> response = logInServiceImpl.reset(reset);

	    }
	  }



