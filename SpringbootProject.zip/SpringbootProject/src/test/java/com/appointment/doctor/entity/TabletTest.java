package com.appointment.doctor.entity;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {Tablet.class })
@ExtendWith(SpringExtension.class)

public class TabletTest {
	@Autowired
    private  Tablet  tablet;

	@MockBean
	private AppointmentService appointmentService;
	@Test
	public void  testgetId()  throws Exception  {
		tablet.getId();
			 }
	@Test
	public void  testsetId()  throws Exception  {
		tablet.setId(0);
			 }

	@Test
	public void  testgetName()  throws Exception  {
		tablet.getName();
			 }

	@Test
	public void  testsetName()  throws Exception  {
String Str="2434";	
tablet.setName(Str);
			 }

	@Test
	public void  testgetQuantityAvailable()  throws Exception  {
		tablet.getQuantityAvailable();
			 }

	@Test
	public void  testsetQuantityAvailable()  throws Exception  {
		int quantityAvailable=34;
		tablet.setQuantityAvailable(quantityAvailable);
			 }
	@Test
	public void  testsetgetPrice()  throws Exception  {
		int quantityAvailable=34;
		tablet.getPrice();
			 }
	@Test
	public void  testsetPrice()  throws Exception  {
		double quantityAvailable=34;
		tablet.setPrice(quantityAvailable);
			 }
	@Test
    public void testToString() {
        Doctor doctor = new Doctor();
        Patient patient = new Patient();
        String status = "PENDING";
        LocalDateTime appointmentAt = LocalDateTime.now();

        Appointment appointment = new Appointment(1, doctor, patient, status, appointmentAt);
        String expectedToString = "Appointment [id=1, doctor=" + doctor + ", patient=" + patient + ", status=" + status
            + ", appointmentAt=" + appointmentAt + "]";

        assertEquals(expectedToString, appointment.toString());
    }
	@Test
    public void testTabletConstructor() {
        int id = 1;
        String name = "Tablet A";
        int quantityAvailable = 50;
        double price = 10.99;

        Tablet tablet = new Tablet(id, name, quantityAvailable, price);

        assertEquals(id, tablet.getId());
        assertEquals(name, tablet.getName());
        assertEquals(quantityAvailable, tablet.getQuantityAvailable());
    }

				 }
