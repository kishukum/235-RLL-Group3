package com.appointment.doctor.entity;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {Appointment.class })
@ExtendWith(SpringExtension.class)

public class AppointmentTest {
	@Autowired
    private Appointment appointment;

	@MockBean
	private AppointmentService appointmentService;
	@Test
	public void  testgetId()  throws Exception  {
		appointment.getId();
			 }
	@Test
	public void  testsetId()  throws Exception  {
		appointment.setId(0);
			 }

	@Test
	public void  testgetDoctor()  throws Exception  {
		appointment.getDoctor();
			 }

	@Test
	public void  testsetDoctor()  throws Exception  {
		Doctor doctor=new Doctor();	
		appointment.setDoctor(doctor);
			 }

	@Test
	public void  testgetPatient()  throws Exception  {
		appointment.getPatient();
			 }

	@Test
	public void  testsetPatient()  throws Exception  {
		Patient patient=new Patient();		
		appointment.setPatient(patient);
			 }

	@Test
	public void  testgetStatus()  throws Exception  {
		appointment.getStatus();
			 }

	@Test
	public void  testsetStatus()  throws Exception  {
		String status="Y";		appointment.setStatus(status);
			 }

	@Test
	public void  testgetAppointmentAt()  throws Exception  {
		appointment.getAppointmentAt();
			 }
	@Test
	public void  testsetAppointmentAt()  throws Exception  {
		LocalDateTime appointmentAt=null;
		appointment.setAppointmentAt(appointmentAt);
			 }
	 @Test
	    public void testAppointmentConstructor() {
	        Doctor doctor = new Doctor();
	        Patient patient = new Patient();
	        String status = "PENDING";
	        LocalDateTime appointmentAt = LocalDateTime.now();

	        Appointment appointment = new Appointment(1, doctor, patient, status, appointmentAt);

	        assertEquals(1, appointment.getId());
	        assertEquals(doctor, appointment.getDoctor());
	        assertEquals(patient, appointment.getPatient());
	        assertEquals(status, appointment.getStatus());
	        assertEquals(appointmentAt, appointment.getAppointmentAt());
	    }
	 @Test
	    public void testToString() {
	        Doctor doctor = new Doctor();
	        Patient patient = new Patient();
	        String status = "PENDING";
	        LocalDateTime appointmentAt = LocalDateTime.now();

	        Appointment appointment = new Appointment(1, doctor, patient, status, appointmentAt);
	        String expectedToString = "Appointment [id=1, doctor=" + doctor + ", patient=" + patient + ", status=" + status
	            + ", appointmentAt=" + appointmentAt + "]";

	        assertEquals(expectedToString, appointment.toString());
	    }
			 }
