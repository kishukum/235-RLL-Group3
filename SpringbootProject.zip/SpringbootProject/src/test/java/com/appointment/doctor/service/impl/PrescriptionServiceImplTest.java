package com.appointment.doctor.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.StringUtils;

import com.appointment.doctor.dto.LogIn;
import com.appointment.doctor.dto.ResetPassword;
import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.entity.Patient;
import com.appointment.doctor.entity.Prescription;
import com.appointment.doctor.entity.Tablet;
import com.appointment.doctor.repository.AppointmentsRepository;
import com.appointment.doctor.repository.DoctorsRepository;
import com.appointment.doctor.repository.PatientRepository;
import com.appointment.doctor.repository.PrescriptionRepository;
import com.appointment.doctor.repository.TabletRepository;
import com.appointment.doctor.service.AppointmentService;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {PrescriptionServiceImpl.class })
@ExtendWith(SpringExtension.class)
public class PrescriptionServiceImplTest {

    @Autowired
	private PrescriptionServiceImpl prescriptionServiceImpl;

	@MockBean
	private DoctorsRepository doctorRepository;

	@MockBean
	private PatientRepository patientRepository;
	@MockBean
	private AppointmentsRepository appointmentRepository;
	@MockBean
	private PrescriptionRepository prescriptionRepository;
	@MockBean
	private TabletRepository tabletrepository;

	@Test
	public void contextLoads() {
	}
	@Test
    public void testSavePrescription() {
        Appointment appointment = new Appointment();
        appointment.setId(1); 
        Prescription prescription = new Prescription();
        prescription.setAppointment(appointment);
        
        List<Tablet> tablets = new ArrayList<>();
        Tablet tablet1 = new Tablet();
        tablet1.setId(1); 
        tablets.add(tablet1);
        prescription.setTablets(tablets);
        when(appointmentRepository.findById(appointment.getId())).thenReturn(Optional.of(appointment));
        ResponseEntity<?> response = prescriptionServiceImpl.save(prescription);


    }
	 @Test
	    public void testGetPatientPrescription() {
	        int patientId = 1; 

	        List<Prescription> prescriptions = new ArrayList<>();
	        prescriptions.add(new Prescription());
	        prescriptions.add(new Prescription());
	        when(prescriptionRepository.findByAppointmentPatientId(patientId)).thenReturn(prescriptions);

	        ResponseEntity<?> response = prescriptionServiceImpl.getPatientPrescription(patientId);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertTrue(response.getBody() instanceof List);
	        assertEquals(prescriptions, response.getBody());
	    }
	 @Test
	    public void testGetPrescriptionFound() {
	        int prescriptionId = 1; // Example prescription ID

	        Prescription prescription = new Prescription();
	        prescription.setId(prescriptionId);
	        when(prescriptionRepository.findById(prescriptionId)).thenReturn(Optional.of(prescription));
	        ResponseEntity<?> response = prescriptionServiceImpl.getPrescription(prescriptionId);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertTrue(response.getBody() instanceof Prescription);
	        assertEquals(prescription, response.getBody());
	    }
    }



