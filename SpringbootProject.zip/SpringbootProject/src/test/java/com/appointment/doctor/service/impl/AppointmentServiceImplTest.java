package com.appointment.doctor.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.StringUtils;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.entity.Patient;
import com.appointment.doctor.repository.AppointmentsRepository;
import com.appointment.doctor.repository.DoctorsRepository;
import com.appointment.doctor.repository.PatientRepository;
import com.appointment.doctor.service.AppointmentService;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {AppointmentServiceImpl.class })
@ExtendWith(SpringExtension.class)
public class AppointmentServiceImplTest {

    @Autowired
	private AppointmentServiceImpl appointmentServiceImpl;

	@MockBean
	private DoctorsRepository doctorRepository;

	@MockBean
	private PatientRepository patientRepository;
	@MockBean
	private AppointmentsRepository appointmentRepository;
	 
	@Test
	public void contextLoads() {
	}
	@Test
	@Order(1)
	public void testbookAppointment() throws Exception {
		Patient patient = new Patient();
        patient.setId(1); 
        Doctor doctor = new Doctor();
        doctor.setId(1); 
        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setDoctor(doctor);

        when(patientRepository.findById(patient.getId())).thenReturn(Optional.of(patient));
        when(doctorRepository.findById(doctor.getId())).thenReturn(Optional.of(doctor));
        when(appointmentRepository.save(appointment)).thenReturn(appointment);

        ResponseEntity<Appointment> response = appointmentServiceImpl.bookAppointment(appointment);

        assertNotNull(response);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(appointment, response.getBody());
    	appointmentServiceImpl.bookAppointment(appointment);
	}
    @Test
    public void testGetDoctorsAppointment() {
        int doctorId = 1; 
        String status = "ALL"; 
        List<Appointment> appointments = new ArrayList<>();
        appointments.add(new Appointment());
        appointments.add(new Appointment());

        if (status.equals("ALL")) {
            when(appointmentRepository.findByDoctorId(doctorId)).thenReturn(appointments);
        } else {
            when(appointmentRepository.findByDoctorIdAndStatus(doctorId, status)).thenReturn(appointments);
        }

        ResponseEntity<List<Appointment>> response = appointmentServiceImpl.getDoctorsAppointment(doctorId, status);

        if (status.equals("ALL")) {
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(appointments, response.getBody());
        } else {
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(appointments, response.getBody());
        }
    }
    @Test
    public void testUpdateStatusSuccess() {
        int appointmentId = 1; 
        String status = "UPDATED"; 

        Appointment existingAppointment = new Appointment();
        existingAppointment.setId(appointmentId);
        existingAppointment.setStatus("PENDING"); // Initial status

        when(appointmentRepository.findById(appointmentId)).thenReturn(Optional.of(existingAppointment));
        when(appointmentRepository.save(any(Appointment.class))).thenAnswer(invocation -> invocation.getArgument(0));

        ResponseEntity<?> response = appointmentServiceImpl.updateStatus(appointmentId, status);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody() instanceof Appointment);
        assertEquals(status, ((Appointment) response.getBody()).getStatus());
    }
    @Test
    public void testGetAppointmentFound() {
        int appointmentId = 1; 
        Appointment existingAppointment = new Appointment();
        existingAppointment.setId(appointmentId);
        existingAppointment.setStatus("PENDING"); 
        when(appointmentRepository.findById(appointmentId)).thenReturn(Optional.of(existingAppointment));
        ResponseEntity<?> response = appointmentServiceImpl.get(appointmentId);

         assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody() instanceof Appointment);
        assertEquals(existingAppointment, response.getBody());
    }
    @Test
    public void testGetPatientAppointmentsAll() {
        int patientId = 1; 
        String status = "ALL"; 
        List<Appointment> appointments = new ArrayList<>();
        appointments.add(new Appointment());
        appointments.add(new Appointment());
        when(appointmentRepository.findByPatientId(patientId)).thenReturn(appointments);
        ResponseEntity<List<Appointment>> response = appointmentServiceImpl.getPatientAppointments(patientId, status);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(appointments, response.getBody());
    }
    @Test
    public void testGetPatientAppointmentsByName() {
        String patientName = "John Doe"; 

        List<Appointment> appointments = new ArrayList<>();
        appointments.add(new Appointment());
        appointments.add(new Appointment());

        when(appointmentRepository.findByPatientName(patientName)).thenReturn(appointments);
        ResponseEntity<List<Appointment>> response = appointmentServiceImpl.getPatientAppointmentsByName(patientName);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(appointments, response.getBody());
    }
}



