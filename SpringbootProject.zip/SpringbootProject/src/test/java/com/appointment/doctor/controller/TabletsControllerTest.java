package com.appointment.doctor.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Tablet;
import com.appointment.doctor.service.AppointmentService;
import com.appointment.doctor.service.TabletsService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {TabletsController.class })
@ExtendWith(SpringExtension.class)

public class TabletsControllerTest {
	@Autowired
    private TabletsController tabletsController;

	@MockBean
	private TabletsService tabletsService;
	@Test
	public void  testsave()  throws Exception  {
		Tablet tablet=new Tablet();		tabletsController.save(tablet);
			 }
	@Test
	public void  testupdate()  throws Exception  {
		Tablet tablet=new Tablet();		tabletsController.update(tablet);
			 }
	@Test
	public void  testgetAll()  throws Exception  {
		int id=3;String status="Y";
		tabletsController.getAll();
			 }
	@Test
	public void  testgetById()  throws Exception  {
		int id=3;String status="Y";
		tabletsController.getById(id);
			 }
	@Test
	public void  testdelete()  throws Exception  {
		int id=3;tabletsController.delete(id);
			 }
	@Test
	public void  testgetByName()  throws Exception  {
String name="veda";
tabletsController.getByName(name);
			 }
}
	
