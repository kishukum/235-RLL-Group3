package com.appointment.doctor.entity;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Date;

import org.junit.Before;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.service.AppointmentService;
import com.fasterxml.jackson.databind.ObjectMapper;
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {Messages.class })
@ExtendWith(SpringExtension.class)

public class MessagesTest {
	@Autowired
    private Messages messages;

	@MockBean
	private AppointmentService appointmentService;
	@Test
	public void  testgetId()  throws Exception  {
		messages.getId();
			 }
	@Test
	public void  testsetId()  throws Exception  {
		messages.setId(0);
			 }

	@Test
	public void  testgetSenderId()  throws Exception  {
		messages.getSenderId();
			 }

	@Test
	public void  testsetSenderId()  throws Exception  {
		int SenderId=8;		messages.setSenderId(SenderId);
			 }

	@Test
	public void  testgetReceiverId()  throws Exception  {
		messages.getReceiverId();
			 }

	@Test
	public void  testsetReceiverId()  throws Exception  {
int ReceiverId=43;	
messages.setReceiverId(ReceiverId);
			 }

	@Test
	public void  testgetMessageAt()  throws Exception  {
		messages.getMessageAt();
			 }

	@Test
	public void  testsetMessageAt()  throws Exception  {
		Date messageAt=null;	messages.setMessageAt(messageAt);
			 }
	@Test
    public void testToString() {
        Doctor doctor = new Doctor();
        Patient patient = new Patient();
        String status = "PENDING";
        LocalDateTime appointmentAt = LocalDateTime.now();

        Appointment appointment = new Appointment(1, doctor, patient, status, appointmentAt);
        String expectedToString = "Appointment [id=1, doctor=" + doctor + ", patient=" + patient + ", status=" + status
            + ", appointmentAt=" + appointmentAt + "]";

        assertEquals(expectedToString, appointment.toString());
    }
	@Test
    public void testMessagesConstructor() {
        int id = 1;
        int senderId = 101;
        int receiverId = 201;
        Date messageAt = new Date(); // You can use any valid date here

        Messages messages = new Messages(id, senderId, receiverId, messageAt);

        assertEquals(id, messages.getId());
        assertEquals(senderId, messages.getSenderId());
        assertEquals(receiverId, messages.getReceiverId());
        assertEquals(messageAt, messages.getMessageAt());
    }
				 }
