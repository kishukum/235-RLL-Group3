package com.appointment.doctor.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.util.Optional;
import org.junit.jupiter.api.Test;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.junit.Before;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.StringUtils;

import com.appointment.doctor.dto.LogIn;
import com.appointment.doctor.dto.ResetPassword;
import com.appointment.doctor.entity.Appointment;
import com.appointment.doctor.entity.Doctor;
import com.appointment.doctor.entity.Patient;
import com.appointment.doctor.entity.Prescription;
import com.appointment.doctor.entity.Tablet;
import com.appointment.doctor.repository.AppointmentsRepository;
import com.appointment.doctor.repository.DoctorsRepository;
import com.appointment.doctor.repository.PatientRepository;
import com.appointment.doctor.repository.PrescriptionRepository;
import com.appointment.doctor.repository.TabletRepository;
import com.appointment.doctor.service.AppointmentService;

@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@ContextConfiguration(classes = {TabletsServiceImpl.class })
@ExtendWith(SpringExtension.class)
public class TabletsServiceImplTest {

    @Autowired
	private TabletsServiceImpl tabletsServiceImpl;

	@MockBean
	private DoctorsRepository doctorRepository;

	@MockBean
	private PatientRepository patientRepository;
	@MockBean
	private AppointmentsRepository appointmentRepository;
	@MockBean
	private PrescriptionRepository prescriptionRepository;
	@MockBean
	private TabletRepository tabletrepository;

	@Test
	public void contextLoads() {
	}
	@Test
    public void testSavePrescription() {
        Appointment appointment = new Appointment();
        appointment.setId(1); 
        Prescription prescription = new Prescription();
        prescription.setAppointment(appointment);
        
        List<Tablet> tablets = new ArrayList<>();
        Tablet tablet1 = new Tablet();
        tablet1.setId(1); 
        tablets.add(tablet1);
        prescription.setTablets(tablets);
        when(appointmentRepository.findById(appointment.getId())).thenReturn(Optional.of(appointment));
        ResponseEntity<?> response = tabletsServiceImpl.save(tablet1);


    }
	@Test
    public void testUpdateTabletExists() {
        Tablet tablet = new Tablet();
        tablet.setName("Example Tablet");

        when(tabletrepository.existsByName(tablet.getName())).thenReturn(true);
        when(tabletrepository.save(tablet)).thenReturn(tablet);

        ResponseEntity<?> response = tabletsServiceImpl.update(tablet);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody() instanceof Tablet);
        assertEquals(tablet, response.getBody());
    }
	@Test
    public void testGetAll() {
        List<Tablet> tablets = new ArrayList<>();
        tablets.add(new Tablet(1, "Tablet A", 10, 9.99));
        tablets.add(new Tablet(2, "Tablet B", 20, 19.99));
        tablets.add(new Tablet(3, "Tablet C", 5, 29.99));

        when(tabletrepository.findAll()).thenReturn(tablets);

        ResponseEntity<List<Tablet>> response = tabletsServiceImpl.getAll();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(tablets.size(), response.getBody().size()); // Check if the number of tablets matches
        assertEquals(tablets.get(0), response.getBody().get(0)); // Check if the first tablet matches
    }
	@Test
    public void testGetByIdExistingTablet() {
        int tabletId = 1;
        Tablet tablet = new Tablet(tabletId, "Tablet A", 10, 9.99);

        when(tabletrepository.findById(tabletId)).thenReturn(Optional.of(tablet));

        ResponseEntity<?> response = tabletsServiceImpl.getById(tabletId);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertTrue(response.getBody() instanceof Tablet);
        assertEquals(tablet, response.getBody());
    }
	@Test
    public void testDeleteById() {
        int tabletIdToDelete = 1;

        doNothing().when(tabletrepository).deleteById(tabletIdToDelete);

        ResponseEntity<String> response = tabletsServiceImpl.deleteById(tabletIdToDelete);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Tablet deleted successfully", response.getBody());
        
        verify(tabletrepository, times(1)).deleteById(tabletIdToDelete);
    }
	 @Test
	    public void testGetByNameExistingTablet() {
	        String tabletName = "Tablet A";
	        Tablet tablet = new Tablet(1, tabletName, 10, 9.99);

	        when(tabletrepository.findByName(tabletName)).thenReturn(tablet);
	        ResponseEntity<?> response = tabletsServiceImpl.getByName(tabletName);

	        assertEquals(HttpStatus.OK, response.getStatusCode());
	        assertTrue(response.getBody() instanceof Tablet);
	        assertEquals(tablet, response.getBody());
	    }
    }



